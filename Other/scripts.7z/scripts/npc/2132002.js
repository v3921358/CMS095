﻿function action(mode, type, selection) {
    cm.sendNext("这片森林的神奇令人嘆为觀止......");
    cm.dispose();
}