﻿/* 
 * NPC  : Donations
 * Maps : Every town
 */

function action(mode, type, selection) {
    cm.sendOk("上面用很小的字寫着，请支付用于村莊建設的捐獻金！ 行善的您会获得好報的。");
    cm.dispose();
}