﻿function action(mode, type, selection) {
    cm.sendNext("叫我黑魔王。看在几年......我会給盜賊的社会地位！");
    cm.dispose();
}