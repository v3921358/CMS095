﻿function action(mode, type, selection) {
    cm.sendNext("樓上就是被黑魔法师破壞的艾靈森林...\r\n我觉得該去看一下。");
    cm.dispose();
}