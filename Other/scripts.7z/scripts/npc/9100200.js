
function action(mode, type, selection) {
    cm.openBeans();
    cm.dispose();
}