﻿/* 	Sejan
	Ariant
*/


function start() {
    cm.sendNext("光明与黑暗總是共存着...");
}

function action() {
    cm.dispose()
}