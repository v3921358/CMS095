﻿function start() {
cm.gainGachaponItemTime(5010150, 1, "月卡会员", 7);	
cm.setBossRankCount9("白金点",0 );	
cm.setBossRankCount9("橙金点",0 );	
cm.setBossRankCount9("紫金点",0 );	
	
	
cm.sendOk("管理员未分配我工作···");
}

