/*
 * Storage - Lung Ton
 */

function start() {
    cm.sendStorage();
    cm.dispose();
}