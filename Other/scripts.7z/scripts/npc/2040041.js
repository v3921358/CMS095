﻿/*
 Aqua Balloon - LudiPQ 6th stage NPC
 */

function start() {
    cm.sendNext("嗨，我是#p2040041# 第六阶段非常简单，只要顺着口号都能过关的，那么剩下时间交给你喽~");
}

function action(mode, type, selection) {
    cm.dispose();
}