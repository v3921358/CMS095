function action(mode, type, selection) {
    cm.sendNext("哈哈！傻瓜！我背叛了你，解封了流浪汉国王雷克斯！");
    cm.dispose();
}