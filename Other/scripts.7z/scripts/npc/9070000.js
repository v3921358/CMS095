var status = -1;

function action(mode, type, selection) {
	//if (cm.getPlayer().isGM()) {
		cm.sendPVPWindow();
	//} else {
	//	cm.sendNext("Patience...");
	//}
	cm.dispose();
}