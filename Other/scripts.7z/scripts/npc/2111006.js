﻿/* Author: aaroncsn(MapleSea Like)(Incomplete)
	NPC Name: 		Parwen
	Map(s): 		Hidden Street: Authorized Person Only(261020401)
	Description: 		Unknown
*/

function start(){
	cm.sendNext("你还沒有准备好。");
	cm.dispose();
	}