﻿var status = -1;

function start() {
    cm.playerMessage("这门没用");
    cm.dispose();
    return;
}