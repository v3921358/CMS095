function start() {
	cm.warp(682000100, 0);
	cm.dispose();
}