/* 	Johnson
	Singapore	
*/


function start() {
    cm.sendOk("Acheww~~~ I can't believe I got a cold in this warm weather.");
}

function action() {
    cm.dispose()
}