/* @Author Lerk
 *
 * Sharen III's Will - Sharenian: Waterway (990000600)
 * 
 * Guild Quest Stage 4 Info
 */

function action(mode, type, selection) {
    cm.sendOk("I fought the Rubian and I lost, and now I am imprisoned in the very gate that blocks my path, my body desecrated. However, my old clothing has holy power within. If you can return the clothing to my body, I should be able to open the gate. Please hurry! \r\n- Sharen III \r\n\r\nP.S. I know this is rather picky of me, but can you please return the clothes to my body #bbottom to top#k? Thank you for your services.");
    cm.safeDispose();
}