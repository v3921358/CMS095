﻿/* 
 * NPC  : Donations
 * Maps : Every town
 */

function action(mode, type, selection) {
    cm.sendOk("#b#h ##k你来看我了！前两天我的#v4001231#丢了，如果你能找回来，我就可以给孩子们送礼物了，随便我在告诉你我的拐杖魔法，怎么使用~");
    cm.dispose();
}