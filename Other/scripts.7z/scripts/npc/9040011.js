﻿/* 
 * @Author Lerk
 * 
 * Bulletin Board, Victoria Road: Excavation Site<Camp> (101030104) AND Sharenian: Excavation Site (990000000)
 * 
 * Start of Guild Quest
 */


function action(mode, type, selection) {
    cm.sendOk("<通知> \r\n你是一个擁有足够的勇氣和信任的行会的一部分吗？然后接受行会挑战，挑战自我！\r\n\r\n#b參与：#k\r\n1.公会必須由至少6人組成！\r\n2. 公会的領導者必須是公会的会长或副会长！\r\n3. 公会的任務可能会很早結束，如果參加工会的会员人數低于6，或者領導决定提前結束。");
    cm.safeDispose();
}