function action(mode, type, selection) {
    cm.sendOk("财富系统目前不可用.");
    cm.dispose();
}